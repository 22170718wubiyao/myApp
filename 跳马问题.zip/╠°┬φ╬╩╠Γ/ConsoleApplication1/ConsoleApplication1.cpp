﻿// ConsoleApplication1.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "pch.h"
#include <iostream>
#include <time.h>
#include <stdlib.h>
const int n = 6 ,m=6;    // 表示棋盘的长n和高m
int qipan[n + 1][m + 1];       // 记录棋盘是否被跳过
static int cmq;               // 步数
int con = 1, OK = 0;         // 没有被使用
int xLabel, yLabel;
void shuchu()
{
	std:: cout << '\t';
	for (int i1 = 1; i1 <= m; i1++)
		std:: cout << i1 << "列" << '\t';
	for (int i = 1; i <= n; i++)
	{
		std::cout << std:: endl;
		std:: cout << i << "行" << '\t';
		for (int j = 1; j <= n; j++)
		{
			std::cout << qipan[i][j] << '\t';
		}
		std::cout << std::endl;

	}
}

int tiaoma(int x, int y)
{
	if (cmq == m * n && ((x - 2 == xLabel && y + 1 == yLabel) || (x - 1 == xLabel && y + 2 == yLabel) || (x + 1 == xLabel && y + 2 == yLabel) || (x + 2 == xLabel && y + 1 == yLabel) || (x + 2 == xLabel && y - 1 == yLabel) || (x + 1 == xLabel && y - 2 == yLabel) || (x - 2 == xLabel && y - 1 == yLabel) || (x - 1 == xLabel && y - 2 == yLabel)))
	{
		shuchu();
		OK = 1;
		return 0;
	}


	if (1 <= x - 2 && y + 1 <= m && qipan[x - 2][y + 1] == 0)
	{
		qipan[x - 2][y + 1] = ++cmq;
		//   1
		tiaoma(x - 2, y + 1);
	}
	if (1 <= x - 1 && y + 2 <= m && qipan[x - 1][y + 2] == 0)
	{
		qipan[x - 1][y + 2] = ++cmq;
		//   2
		tiaoma(x - 1, y + 2);
	}
	if (x + 1 <= n && y + 2 <= m && qipan[x + 1][y + 2] == 0)
	{
		qipan[x + 1][y + 2] = ++cmq;
		//   3
		tiaoma(x + 1, y + 2);
	}
	if (x + 2 <= n && y + 1 <= m && qipan[x + 2][y + 1] == 0)
	{
		qipan[x + 2][y + 1] = ++cmq;
		//   4
		tiaoma(x + 2, y + 1);
	}



	if (x + 2 <= n && 1 <= y - 1 && qipan[x + 2][y - 1] == 0)
	{
		qipan[x + 2][y - 1] = ++cmq;
		//   5

		tiaoma(x + 2, y - 1);
	}
	if (x + 1 <= n && 1 <= y - 2 && qipan[x + 1][y - 2] == 0)
	{
		qipan[x + 1][y - 2] = ++cmq;
		//   6
		tiaoma(x + 1, y - 2);
	}
	if (1 <= x - 1 && 1 <= y - 2 && qipan[x - 1][y - 2] == 0)
	{
		qipan[x - 1][y - 2] = ++cmq;
		//   7
		tiaoma(x - 1, y - 2);
	}
	if (1 <= x - 2 && 1 <= y - 1 && qipan[x - 2][y - 1] == 0)
	{
		qipan[x - 2][y - 1] = ++cmq;
		//   8
		tiaoma(x - 2, y - 1);
	}



	cmq--;
	qipan[x][y] = 0;



	// 回朔
	return 0;
}

int main()
{
	unsigned beg, end;
	beg = (unsigned)time(NULL);

	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			qipan[i][j] = 0;


	for (int i = 1; i <= n; i++)         //该处分别计算从点(1,1)到点(n,n)作为起始点，可以找到哪些回路
		for (int j = 1; j <= m; j++)
		{
			xLabel = i;
			yLabel = j;
			cmq = 1;
			for (int k1 = 1; k1 <= n; k1++)
				for (int k2 = 1; k2 <= m; k2++)
					qipan[k1][k2] = 0;
			qipan[i][j] = 1;
			tiaoma(i, j);
		}

	if (OK != 1)
	{
		std:: cout << std:: endl << "当n＝" << n << "时无回路" << std:: endl;
		std::cout << std::endl << "当m＝" << m << "时无回路" << std::endl;
	}
	end = (unsigned)time(NULL);
	std:: cout << end - beg << "s .";
	return 0;
}





// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门提示: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
